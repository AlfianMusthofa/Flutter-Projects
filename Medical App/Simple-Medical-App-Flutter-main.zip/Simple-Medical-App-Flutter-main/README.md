## Simple Medical App UI Design
Dibuat untuk sekadar berlatih flutter

## Tech Stack
- Dart
- Flutter
 
## ScreenShot
![NotesLiteImage](Visual.png)
