import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:medical_app/components/doctor.dart';
import 'package:medical_app/components/header_home.dart';
import 'package:medical_app/components/input_field.dart';
import 'package:medical_app/pages/doctor_detail.dart';

class HomePage extends StatelessWidget {
  TextEditingController searchCon = TextEditingController();
  HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Center(
              child: Column(
                children: [
                  // Header
                  HeaderHome(),
                  SizedBox(height: 20),
                  // SearchField
                  InputField(
                    hintText: 'Search here...',
                    obscureText: false,
                    controller: searchCon,
                    borderRadius: BorderRadius.circular(5),
                  ),

                  SizedBox(height: 16),

                  // Row Specialist
                  Container(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              'Specialist',
                              style: GoogleFonts.poppins(
                                  textStyle: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w500)),
                            ),
                          ],
                        ),

                        SizedBox(height: 10),

                        // Row Doctor
                        Container(
                          height: 210,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              DoctorSpecialist(
                                  doctorName: 'Dr. Richard Miles',
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                DoctorDetail()));
                                  },
                                  specialist: 'Dentist Surgeon',
                                  imagePath: 'assets/images/doctor.png'),
                              DoctorSpecialist(
                                  doctorName: 'Dr. Mahbula Islam',
                                  onTap: () {},
                                  specialist: 'Dentist Surgeon',
                                  imagePath: 'assets/images/doctor2.png'),
                              DoctorSpecialist(
                                  doctorName: 'Dr. Kawsar Ahmed',
                                  onTap: () {},
                                  specialist: 'Dentist Surgeon',
                                  imagePath: 'assets/images/doctor3.png'),
                              DoctorSpecialist(
                                  doctorName: 'Dr. Kawsar Ahmed',
                                  onTap: () {},
                                  specialist: 'Dentist Surgeon',
                                  imagePath: 'assets/images/doctor4.png'),
                              DoctorSpecialist(
                                  doctorName: 'More',
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                MoreSpecialist()));
                                  },
                                  specialist: '',
                                  imagePath: 'assets/images/more.png'),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Row options
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 30),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        DoctorIcon(
                          iconPath: 'assets/images/icondoctor.png',
                          label: 'Doctor',
                        ),
                        DoctorIcon(
                          iconPath: 'assets/images/iconcalendar.png',
                          label: 'Appointment',
                        ),
                        DoctorIcon(
                          iconPath: 'assets/images/iconprescription.png',
                          label: 'Prescription',
                        ),
                        DoctorIcon(
                          iconPath: 'assets/images/iconmedicine.png',
                          label: 'Medicine',
                        ),
                      ],
                    ),
                  ),

                  // Row Available doctor
                  Row(
                    children: [
                      Text(
                        'Available Doctor',
                        style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w500)),
                      )
                    ],
                  ),
                  SizedBox(height: 10),
                  Container(
                    height: 160,
                    child: PageView(
                      scrollDirection: Axis.horizontal,
                      children: [
                        AvailableDoctor(
                          doctorName: 'Dr.Richard Miles',
                          imagePath: 'assets/images/doctor.png',
                        ),
                        AvailableDoctor(
                          doctorName: 'Dr.Rika Johansen',
                          imagePath: 'assets/images/doctor2.png',
                        ),
                        AvailableDoctor(
                          doctorName: 'Dr.Rika Johansen',
                          imagePath: 'assets/images/doctor3.png',
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
