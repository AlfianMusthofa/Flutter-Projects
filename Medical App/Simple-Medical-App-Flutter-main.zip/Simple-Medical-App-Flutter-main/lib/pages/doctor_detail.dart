import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:medical_app/components/experience.dart';

class DoctorDetail extends StatelessWidget {
  const DoctorDetail({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        iconTheme: IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              // Header
              Container(
                decoration: BoxDecoration(color: Colors.blue),
                child: Center(
                  child: Column(
                    children: [
                      Text(
                        'Doctor Detail',
                        style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                                fontSize: 20,
                                color: Colors.white,
                                fontWeight: FontWeight.w500)),
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 20),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10)),
                        child: Image.asset('assets/images/doctor.png',
                            height: 150),
                      ),

                      // Experience
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 30),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Experience(
                              imagePath: 'assets/images/iconheart.png',
                              text1: '150+',
                              text2: 'Patients',
                            ),
                            SizedBox(width: 35),
                            Experience(
                              imagePath: 'assets/images/iconcrown.png',
                              text1: '10 years',
                              text2: 'Experience',
                            ),
                            SizedBox(width: 35),
                            Experience(
                              imagePath: 'assets/images/iconstar.png',
                              text1: '4.9',
                              text2: 'Rating',
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),

              // Body
              Container(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    // Doctor Name
                    Column(
                      children: [
                        Text(
                          'Dr.Richard Miles',
                          style: GoogleFonts.poppins(
                              textStyle: TextStyle(
                                  fontSize: 23, fontWeight: FontWeight.w600)),
                        ),
                        Text(
                          'Cardiologist-Cumila Medical Collage',
                          style: GoogleFonts.poppins(
                              textStyle: TextStyle(color: Colors.grey[500])),
                        ),
                        SizedBox(height: 5),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset('assets/images/iconstar.png',
                                height: 20),
                            SizedBox(width: 8),
                            Image.asset('assets/images/iconstar.png',
                                height: 20),
                            SizedBox(width: 8),
                            Image.asset('assets/images/iconstar.png',
                                height: 20),
                            SizedBox(width: 8),
                            Image.asset('assets/images/iconstar.png',
                                height: 20),
                            SizedBox(width: 8),
                            Image.asset('assets/images/iconstar.png',
                                height: 20),
                          ],
                        )
                      ],
                    ),

                    SizedBox(height: 30),

                    // About Doctor
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'About Doctor',
                          style: GoogleFonts.poppins(
                              textStyle: TextStyle(
                                  fontSize: 18, fontWeight: FontWeight.w500)),
                        ),
                        SizedBox(height: 10),
                        Text(
                          'Dr. Richard Miles is the top most cardiologist specialist in Cumila Medical Collage Hospital at Cumila. He achive several awards for his worderfil contrbution in his own field. He is available for private consultation.',
                          style: GoogleFonts.poppins(
                              textStyle: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.grey[700])),
                        ),
                      ],
                    ),

                    SizedBox(height: 20),

                    // Floating Button
                    MaterialButton(
                      onPressed: () {},
                      color: Colors.blue,
                      child: Container(
                        padding: EdgeInsets.all(20),
                        child: Center(
                          child: Text(
                            'Get Appointment',
                            style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600)),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
