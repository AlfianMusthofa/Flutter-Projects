import 'package:flutter/material.dart';
import 'package:medical_app/pages/cart.dart';
import 'package:medical_app/pages/home.dart';
import 'package:medical_app/pages/profile.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  int currentSelectedIndex = 0;

  void navigateBottomBar(int index) {
    setState(() {
      currentSelectedIndex = index;
    });
  }

  final List _list = [
    HomePage(),
    CartPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _list[currentSelectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentSelectedIndex,
        selectedItemColor: Colors.pink,
        onTap: navigateBottomBar,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.card_travel), label: 'Shipment'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_2_outlined), label: 'Profile'),
        ],
      ),
    );
  }
}
