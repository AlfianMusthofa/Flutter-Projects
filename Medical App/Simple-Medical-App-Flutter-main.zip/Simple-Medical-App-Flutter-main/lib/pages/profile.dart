import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:medical_app/components/profile_tile.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  void signUserOut() {
    FirebaseAuth.instance.signOut();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            children: [
              // Header
              Container(
                padding: EdgeInsets.all(25),
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
                child: Center(
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/FotoProfil2.JPG',
                      height: 130,
                      width: 130,
                    ),
                  ),
                ),
              ),

              // Body
              Container(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Basic Information',
                      style: GoogleFonts.poppins(
                          textStyle:
                              TextStyle(fontSize: 15, color: Colors.blue)),
                    ),
                    SizedBox(height: 25),
                    // Profile options tile
                    ProfileTile(
                      onTap: () {},
                      optionName: 'Name',
                      optionValue: 'John Doe',
                    ),
                    SizedBox(height: 40),
                    ProfileTile(
                      onTap: () {},
                      optionName: 'Date of birth',
                      optionValue: '20/05/1990',
                    ),
                    SizedBox(height: 40),
                    ProfileTile(
                      onTap: () {},
                      optionName: 'Gender',
                      optionValue: 'Male',
                    ),
                    SizedBox(height: 40),
                    ProfileTile(
                      onTap: () {},
                      optionName: 'Location',
                      optionValue: 'Bandung',
                    ),
                    SizedBox(height: 40),
                    ProfileTile(
                      onTap: () {},
                      optionName: 'Email',
                      optionValue: 'Johndoe123@gmail.com',
                    ),
                    SizedBox(height: 40),
                    ProfileTile(
                      onTap: () {},
                      optionName: 'Phone',
                      optionValue: '+ 65 8873 6672',
                    ),
                    SizedBox(height: 25),
                    Divider(),
                    SizedBox(height: 17),

                    // Addon Tiles
                    TileAddOn(
                      onTap: () {},
                      optionName: 'Settings',
                      icon: Icons.settings,
                    ),
                    SizedBox(height: 40),
                    TileAddOn(
                      onTap: signUserOut,
                      optionName: 'Sign Out',
                      icon: Icons.login,
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
