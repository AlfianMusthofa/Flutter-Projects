import 'package:flutter/material.dart';
import 'package:medical_app/components/button.dart';
import 'package:medical_app/components/input_field.dart';
import 'package:medical_app/pages/login.dart';

class SignUpPage extends StatelessWidget {
  final TextEditingController signupUsernameController =
      TextEditingController();
  final TextEditingController signupPasswordController =
      TextEditingController();

  SignUpPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(23),
        child: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Ayo Masuk
            const Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Selamat Datang,',
                      style:
                          TextStyle(fontSize: 27, fontWeight: FontWeight.w500),
                    ),
                    Text(
                      'Ayo Mendaftar',
                      style: TextStyle(fontSize: 19),
                    ),
                  ],
                )
              ],
            ),
            // TextField
            Container(
              margin: EdgeInsets.symmetric(vertical: 40),
              child: Column(
                children: [
                  InputField(
                    hintText: 'Username',
                    obscureText: false,
                    controller: signupUsernameController,
                    borderRadius: BorderRadius.circular(5),
                  ),
                  SizedBox(height: 15),
                  InputField(
                    hintText: 'Password',
                    obscureText: true,
                    controller: signupPasswordController,
                    borderRadius: BorderRadius.circular(5),
                  ),
                ],
              ),
            ),
            // Button
            MyButton(
              onTap: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              buttonName: 'Daftar',
            ),
            // Registrasi
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Sudah punya akun? ',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w400),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => LoginPage()));
                  },
                  child: Text(
                    'Masuk Sekarang',
                    style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue),
                  ),
                )
              ],
            )
          ],
        )),
      ),
    );
  }
}
