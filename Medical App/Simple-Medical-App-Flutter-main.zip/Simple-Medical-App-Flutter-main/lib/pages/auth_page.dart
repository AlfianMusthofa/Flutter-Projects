import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:medical_app/pages/introScreen.dart';
import 'package:medical_app/pages/login.dart';
// import 'package:medical_app/pages/login.dart';
import 'package:medical_app/pages/welcome_page.dart';

class AuthPage extends StatelessWidget {
  const AuthPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          // Jika user login
          if (snapshot.hasData) {
            return WelcomePage();
          } else {
            return LoginPage();
          }
        },
      ),
    );
  }
}
