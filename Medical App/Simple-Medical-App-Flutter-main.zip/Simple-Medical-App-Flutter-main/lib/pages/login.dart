import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:medical_app/components/button.dart';
import 'package:medical_app/components/input_field.dart';
import 'package:medical_app/pages/signup.dart';
// import 'package:medical_app/pages/welcome_page.dart';
import 'package:google_fonts/google_fonts.dart';

class LoginPage extends StatefulWidget {
  LoginPage({super.key, required});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController emailController = TextEditingController();

  final TextEditingController passwordController = TextEditingController();

  void signUserIn() async {
    // Menampilkan loading circle
    showDialog(
      context: context,
      builder: (context) {
        return const Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text,
        password: passwordController.text,
      );
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      Navigator.pop(context);
      if (e.code == 'user-not-found') {
        print('User not found');
      } else if (e.code == 'wrong-password') {
        print('Wrong Password');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(23),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Ayo Masuk
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(height: 200),
                        Text('Ayo Masuk,',
                            style: GoogleFonts.poppins(
                                textStyle: TextStyle(
                              fontSize: 27,
                              fontWeight: FontWeight.w600,
                            ))),
                        Text(
                          'Selamat Datang Kembali',
                          style: GoogleFonts.poppins(
                            textStyle: TextStyle(fontSize: 18),
                          ),
                        ),
                      ],
                    )
                  ],
                ),
                // TextField
                Container(
                  margin: EdgeInsets.symmetric(vertical: 40),
                  child: Column(
                    children: [
                      InputField(
                        hintText: 'Username',
                        obscureText: false,
                        controller: emailController,
                        borderRadius: BorderRadius.circular(5),
                      ),
                      SizedBox(height: 15),
                      InputField(
                        hintText: 'Password',
                        obscureText: true,
                        controller: passwordController,
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ],
                  ),
                ),
                // Button
                MyButton(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5)),
                  onTap: signUserIn,
                  buttonName: 'Masuk',
                ),
                // Registrasi
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Belum punya akun? ',
                        style: GoogleFonts.poppins(
                          textStyle: TextStyle(
                              fontSize: 15, fontWeight: FontWeight.w400),
                        )),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => SignUpPage()));
                      },
                      child: Text(
                        'Daftar Sekarang',
                        style: GoogleFonts.poppins(
                            textStyle: TextStyle(
                          fontSize: 15,
                          color: Colors.blue,
                          fontWeight: FontWeight.w500,
                        )),
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
