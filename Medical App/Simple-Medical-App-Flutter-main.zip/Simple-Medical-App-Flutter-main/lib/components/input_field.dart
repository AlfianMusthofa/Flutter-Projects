import 'package:flutter/material.dart';

class InputField extends StatelessWidget {
  final hintText;
  final obscureText;
  final TextEditingController controller;
  final BorderRadius borderRadius;
  const InputField({
    super.key,
    required this.hintText,
    required this.obscureText,
    required this.controller,
    required this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        fillColor: Colors.white,
        filled: true,
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.grey),
          borderRadius: borderRadius,
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(color: Colors.pink),
          borderRadius: borderRadius,
        ),
        hintText: hintText,
      ),
      obscureText: obscureText,
    );
  }
}
