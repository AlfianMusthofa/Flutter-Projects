import 'package:flutter/material.dart';

class MyButton extends StatelessWidget {
  final Function()? onTap;
  final buttonName;
  final ShapeBorder shape;
  const MyButton(
      {super.key,
      required this.onTap,
      required this.buttonName,
      required this.shape});

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onTap,
      padding: EdgeInsets.symmetric(vertical: 19),
      color: Colors.blue,
      shape: shape,
      child: Center(
        child: Text(
          buttonName,
          style: TextStyle(
            fontSize: 15,
            color: Colors.white,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
