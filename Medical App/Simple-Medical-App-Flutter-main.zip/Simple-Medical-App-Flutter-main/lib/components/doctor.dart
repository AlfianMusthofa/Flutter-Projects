import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:medical_app/components/input_field.dart';

class DoctorSpecialist extends StatelessWidget {
  final Function()? onTap;
  final doctorName;
  final specialist;
  final imagePath;

  const DoctorSpecialist(
      {super.key,
      required this.doctorName,
      required this.onTap,
      required this.specialist,
      required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(right: 15),
        child: Column(
          children: [
            // Doctor Image
            Container(
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Image.asset(
                imagePath,
                height: 155,
              ),
            ),

            SizedBox(height: 10),

            // Doctor Name
            Column(
              children: [
                Text(
                  doctorName,
                  style: GoogleFonts.poppins(
                      textStyle: TextStyle(fontWeight: FontWeight.w700)),
                ),
                SizedBox(height: 5),
                Text(
                  specialist,
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(fontSize: 12),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

class DoctorIcon extends StatelessWidget {
  final label;
  final iconPath;

  const DoctorIcon({super.key, required this.iconPath, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
      width: 90,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(iconPath, height: 50),
          SizedBox(height: 5),
          Text(
            label,
            style: TextStyle(fontSize: 13),
          )
        ],
      ),
    );
  }
}

class AvailableDoctor extends StatelessWidget {
  final doctorName;
  final imagePath;
  const AvailableDoctor(
      {super.key, required this.doctorName, required this.imagePath});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Colors.blue, borderRadius: BorderRadius.circular(10)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            margin: EdgeInsets.only(top: 7, left: 7),
            padding: EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Looking For Your Dentist\nSpecial Doctor',
                  style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w600)),
                ),
                SizedBox(height: 10),
                Text(
                  doctorName,
                  style: GoogleFonts.poppins(
                      textStyle: TextStyle(color: Colors.white)),
                ),
                Text(
                  'Jan 25 2024',
                  style: TextStyle(fontSize: 11, color: Colors.white),
                )
              ],
            ),
          ),
          Image.asset(imagePath, height: 160)
        ],
      ),
    );
  }
}

// More Speciallists Tiles
class Specialists extends StatelessWidget {
  final doctorName;
  final pathImage;
  const Specialists(
      {super.key, required this.doctorName, required this.pathImage});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 15),
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(8)),
      padding: EdgeInsets.all(10),
      child: Row(
        children: [
          // Image
          Container(
            decoration: BoxDecoration(
                color: Colors.blue, borderRadius: BorderRadius.circular(5)),
            child: Image.asset(
              pathImage,
              height: 85,
            ),
          ),
          SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                doctorName,
                style: GoogleFonts.poppins(
                    textStyle:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              ),
              Text(
                'Cardiologist-Cumila Medical College',
                style: GoogleFonts.poppins(
                    textStyle:
                        TextStyle(fontSize: 12, color: Colors.grey[600])),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(5),
                    decoration: BoxDecoration(color: Colors.grey[200]),
                    child: Text(
                      '10.20 AM - 12.30 PM',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Colors.blue),
                    ),
                  ),
                  SizedBox(width: 95),
                  Image.asset('assets/images/iconplus.png', height: 25)
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}

// More specialists Page
class MoreSpecialist extends StatelessWidget {
  MoreSpecialist({super.key});

  @override
  Widget build(Object context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.grey[200],
      ),
      backgroundColor: Colors.grey[200],
      body: const SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      'Specialists',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                    )
                  ],
                ),

                SizedBox(height: 10),
                // Tile
                Specialists(
                  pathImage: 'assets/images/doctor.png',
                  doctorName: 'Dr.Richard Miles',
                ),
                Specialists(
                  pathImage: 'assets/images/doctor2.png',
                  doctorName: 'Dr.Angela Hadid',
                ),
                Specialists(
                  pathImage: 'assets/images/doctor3.png',
                  doctorName: 'Dr.Alise Johansen',
                ),
                Specialists(
                  pathImage: 'assets/images/doctor4.png',
                  doctorName: 'Dr.Steve',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
