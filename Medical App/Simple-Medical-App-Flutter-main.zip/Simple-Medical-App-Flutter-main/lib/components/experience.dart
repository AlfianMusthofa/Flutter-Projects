import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Experience extends StatelessWidget {
  final imagePath;
  final text1;
  final text2;
  const Experience(
      {super.key,
      required this.imagePath,
      required this.text1,
      required this.text2});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          // Icon
          Container(
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(30)),
            child: Image.asset(imagePath, height: 30),
          ),
          SizedBox(height: 10),
          Text(
            text1,
            style: TextStyle(
                fontSize: 20, color: Colors.white, fontWeight: FontWeight.w500),
          ),
          Text(
            text2,
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }
}
