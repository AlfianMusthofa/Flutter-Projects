import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ProfileTile extends StatelessWidget {
  final Function()? onTap;
  final String optionName;
  final String optionValue;

  const ProfileTile(
      {super.key,
      required this.onTap,
      required this.optionName,
      required this.optionValue});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            optionName,
            style: GoogleFonts.poppins(
                textStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            )),
          ),
          Row(
            children: [
              Text(optionValue,
                  style: GoogleFonts.poppins(
                      textStyle: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[700],
                  ))),
              SizedBox(width: 20),
              Icon(
                Icons.keyboard_arrow_right,
                color: Colors.grey[700],
              ),
            ],
          )
        ],
      ),
    );
  }
}

class TileAddOn extends StatelessWidget {
  final Function()? onTap;
  final String optionName;
  final IconData icon;
  const TileAddOn(
      {super.key,
      required this.onTap,
      required this.optionName,
      required this.icon});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            optionName,
            style: GoogleFonts.poppins(
                textStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            )),
          ),
          Icon(
            icon,
            color: Colors.grey[700],
          ),
        ],
      ),
    );
  }
}
